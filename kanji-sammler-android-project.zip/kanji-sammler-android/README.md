# Kanji-Sammler – Android APK wrapper

Diese Version verpackt die bestehende Kanji-Sammler-Web-App als eigenständige Android-App. Die gesamte Web-App liegt lokal unter `app/src/main/assets/www/`.

## Bauen

Das GitHub-Workflow-File `.github/workflows/build-apk.yml` baut automatisch ein Debug-APK mit Android Gradle Plugin 9.4.0, Gradle 9.6.0 und Android SDK 36.

Für lokale Builds ist Android Studio/Android SDK erforderlich.

## Offline

Die App lädt die Lernoberfläche und eingebauten Daten aus dem APK selbst. Netzwerk ist für den Grundbetrieb nicht erforderlich.
