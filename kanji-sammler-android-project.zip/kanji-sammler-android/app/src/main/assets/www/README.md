# Kanji-Sammler v0.9

Mobile-first offline PWA für japanische Schriftzeichen, persönliche Sammlungen, Karteikarten und Quiz.

## Architektur
- `index.html` ist nur App-Shell.
- `css/app.css` enthält das Design.
- `js/db.js` kapselt IndexedDB.
- `js/store.js` enthält Zustand, Migration, Backup und Spaced Repetition.
- `js/data.js` kapselt Datenkatalog, automatische Online-Anreicherung und lokale Caches.
- `js/search.js` enthält die gerankte lokale Suche.
- `js/app.js` enthält UI und Interaktionen.
- `data/` ist in Kanji-, Kana-, Wörterbuch- und Quellen-Daten aufgeteilt.

## Offline-Bestand
- 2.136 Jōyō-Kanji als kompletter Zeichenkatalog.
- lokaler Satz detaillierter Kanji-Datensätze plus automatische Anreicherung aus kanjiapi.dev, sobald die App online läuft.
- Hiragana- und Katakana-Bestand getrennt, inklusive Grundzeichen, Dakuten/Handakuten, Yōon, Fremdlautkombinationen und kleinen Kana.
- deutsch-japanischer Seed für häufige Begriffe; er ist kein vollständiger JMdict-Mirror.

## Lernen
Karteikarten mit Flip, Status (neu/unsicher/gelernt), Spaced Repetition, Tagessession, Fokusmodus, Fehlerwiederholung, Wischgesten, optionaler Romaji-Hilfe und Schreibübungen.

## Quiz
Hiragana, Katakana, Kanji, eigene Wörter oder gemischt; Multiple Choice, Eingabe oder Schreiben; Richtung und Kanji-Fragetyp wählbar; Status- und Level-Filter; Kategoriegewichtung; Fehlerwiederholung.

## Quellen
KANJIDIC2 / EDRDG, JMdict / EDRDG, KanjiVG, Unicode, kanjiapi.dev und OpenJLPT. Die App enthält die Quellen-/Lizenzhinweise in der Oberfläche.

Hinweis: KANJIDIC2 umfasst deutlich mehr Zeichen als der lokale 2.136-Jōyō-Bestand. Der große Katalog und erweiterte Detaildaten können online synchronisiert und anschließend lokal gecacht werden. Moderne JLPT-Level werden in der App ausdrücklich als Lernhilfe behandelt, nicht als offizielle vollständige Test-Spezifikation.
