/* IndexedDB persistence layer */
(function(){
  const NAME='kanji-sammler-db'; const VERSION=7;
  const STORES=['meta','folders','cards','progress','dictionary','stroke','settings']; let dbPromise=null;
  function open(){
    if(!('indexedDB' in window)) return Promise.reject(new Error('IndexedDB unavailable'));
    if(dbPromise)return dbPromise;
    dbPromise=new Promise((resolve,reject)=>{
      const r=indexedDB.open(NAME,VERSION);
      r.onupgradeneeded=()=>{const db=r.result; for(const name of STORES){if(!db.objectStoreNames.contains(name))db.createObjectStore(name,{keyPath:'id'});} };
      r.onsuccess=()=>resolve(r.result); r.onerror=()=>{dbPromise=null;reject(r.error||new Error('IndexedDB error'))};
    });
    return dbPromise;
  }
  async function run(store,mode,fn){const db=await open();return new Promise((resolve,reject)=>{const t=db.transaction(store,mode),os=t.objectStore(store);let out;try{out=fn(os)}catch(e){reject(e);return}t.oncomplete=()=>resolve(out);t.onerror=()=>reject(t.error||new Error('transaction failed'))})}
  const get=(s,id)=>run(s,'readonly',os=>new Promise(res=>{const q=os.get(id);q.onsuccess=()=>res(q.result||null);q.onerror=()=>res(null)}));
  const all=s=>run(s,'readonly',os=>new Promise(res=>{const q=os.getAll();q.onsuccess=()=>res(q.result||[]);q.onerror=()=>res([])}));
  const put=(s,v)=>run(s,'readwrite',os=>os.put(v));
  const remove=(s,id)=>run(s,'readwrite',os=>os.delete(id));
  const clear=s=>run(s,'readwrite',os=>os.clear());
  async function bulkPut(s,items){if(!items.length)return;const db=await open();return new Promise((res,rej)=>{const t=db.transaction(s,'readwrite'),os=t.objectStore(s);for(const v of items)os.put(v);t.oncomplete=()=>res();t.onerror=()=>rej(t.error)})}
  async function clearState(){for(const s of ['folders','cards','progress','settings','meta'])await clear(s)}
  window.KS_DB={open,get,all,put,remove,clear,bulkPut,clearState,stores:STORES};
})();
