/* Persistent state, IndexedDB-first storage, migrations and adaptive light SRS. */
(function(){
  const FALL='kanji-sammler-fallback-v9';
  const DAY=86400000, TEN_MIN=600000;
  const today=()=>new Date().toISOString().slice(0,10);
  const base=()=>({
    schema:9,
    settings:{theme:'system',dailyNew:10,gestures:true,syncOnStart:true,romaji:true,dense:false},
    folders:[
      {id:'f-n5',name:'JLPT / Grundwortschatz',icon:'五',cardIds:[]},
      {id:'f-everyday',name:'Alltag',icon:'日',cardIds:[]}
    ],
    cards:[],progress:{},
    daily:{date:today(),newSeen:0,asked:0,correct:0,wrong:0,hard:0,ms:0},
    reviewLog:[],lastSession:null
  });
  let state=base(),fallback=false;
  const clone=x=>JSON.parse(JSON.stringify(x));
  function ensure(){
    const b=base();
    state={...b,...state,schema:9,
      settings:{...b.settings,...(state.settings||{})},
      folders:Array.isArray(state.folders)?state.folders:[],cards:Array.isArray(state.cards)?state.cards:[],
      progress:state.progress&&typeof state.progress==='object'?state.progress:{},
      daily:state.daily?.date===today()?{...b.daily,...state.daily,hard:Number(state.daily.hard||0)}:{...b.daily},
      reviewLog:Array.isArray(state.reviewLog)?state.reviewLog:[]};
  }
  async function persist(){
    ensure();
    if(fallback){localStorage.setItem(FALL,JSON.stringify(state));return state;}
    await KS_DB.bulkPut('folders',state.folders);
    await KS_DB.bulkPut('cards',state.cards);
    await KS_DB.bulkPut('progress',Object.entries(state.progress).map(([id,v])=>({id,...v})));
    await KS_DB.put('settings',{id:'settings',value:state.settings});
    await KS_DB.put('meta',{id:'daily',value:state.daily});
    await KS_DB.put('meta',{id:'reviewLog',value:state.reviewLog.slice(-5000)});
    await KS_DB.put('meta',{id:'lastSession',value:state.lastSession});
    await KS_DB.put('meta',{id:'schema',value:9});
    return state;
  }
  function normaliseProgress(v){
    const s=v||{};
    return {id:s.id,status:['new','unsure','learned'].includes(s.status)?s.status:'new',reps:Number(s.reps||0),interval:Number(s.interval||0),ease:Number(s.ease||2.5),correct:Number(s.correct||0),wrong:Number(s.wrong||0),lastSeen:Number(s.lastSeen||0),lastMs:Number(s.lastMs||0),due:Number(s.due||0),newSeen:!!s.newSeen};
  }
  async function migrateLegacy(){
    for(const key of ['kanji-sammler-v08','kanji-sammler-v07','kanji-sammler-v05','kanji-sammler-v04','kanji-sammler-v3']){
      let old=null;try{const raw=localStorage.getItem(key);if(!raw)continue;old=JSON.parse(raw)}catch(e){continue}
      if(!old)continue;
      for(const f of Array.isArray(old.folders)?old.folders:[]){
        const nf={id:f.id||'folder-'+Date.now()+Math.random().toString(36).slice(2),name:f.name||'Import',icon:f.icon||'文',cardIds:[]};
        const cs=Array.isArray(f.cards)?f.cards:(Array.isArray(f.entries)?f.entries:[]);
        for(const c of cs){
          const id=c.id||'card-'+Date.now()+Math.random().toString(36).slice(2);
          const card={id,kind:c.kind||'word',key:c.key||c.word||c.entry||c.kanji||id,front:c.front||c.word||c.entry||c.kanji||'',reading:c.reading||'',meaning:c.meaning||'',notes:c.notes||'',source:'migrated'};
          if(!state.cards.some(x=>x.id===id))state.cards.push(card);
          if(!nf.cardIds.includes(id))nf.cardIds.push(id);
        }
        if(!state.folders.some(x=>x.id===nf.id))state.folders.push(nf);
      }
      if(old.progress&&typeof old.progress==='object'){
        for(const [type,vals] of Object.entries(old.progress))if(vals&&typeof vals==='object')for(const [key2,val] of Object.entries(vals)){
          const id=type+':'+key2,status=typeof val==='string'?val:(val?.status||'new');
          state.progress[id]=normaliseProgress({id,status,reps:status==='learned'?3:0,interval:status==='learned'?7:0,ease:2.5,due:status==='learned'?Date.now()+7*DAY:0});
        }
      }
      try{localStorage.removeItem(key)}catch(e){}
      break;
    }
  }
  async function load(){
    try{
      const [fs,cards,pg,set,daily,log,last]=await Promise.all([
        KS_DB.all('folders'),KS_DB.all('cards'),KS_DB.all('progress'),KS_DB.get('settings','settings'),KS_DB.get('meta','daily'),KS_DB.get('meta','reviewLog'),KS_DB.get('meta','lastSession')
      ]);
      if(fs.length||cards.length||pg.length){
        state=base();state.folders=fs;state.cards=cards;state.progress=Object.fromEntries(pg.map(v=>{const{id,...rest}=v;return[id,normaliseProgress({id,...rest})]}));
        state.settings=set?.value||state.settings;state.daily=daily?.value||state.daily;state.reviewLog=log?.value||[];state.lastSession=last?.value||null;
      }else{
        const raw=localStorage.getItem(FALL);if(raw)state=JSON.parse(raw);else{state=base();await migrateLegacy();}
        ensure();await persist();
      }
    }catch(e){
      fallback=true;try{const raw=localStorage.getItem(FALL);state=raw?JSON.parse(raw):base();ensure();if(!raw)await migrateLegacy();localStorage.setItem(FALL,JSON.stringify(state));}catch(_){state=base()}
    }
    ensure();return state;
  }
  const get=()=>state;
  const key=(kind,id)=>kind+':'+id;
  function progress(kind,id){return normaliseProgress(state.progress[key(kind,id)])}
  function patchProgress(kind,id,patch){const k=key(kind,id);state.progress[k]={...progress(kind,id),...patch,id:k}}
  function markNewSeen(kind,id){const p=progress(kind,id);if(!p.newSeen){p.newSeen=true;if(state.daily.date!==today())state.daily={date:today(),newSeen:0,asked:0,correct:0,wrong:0,hard:0,ms:0};state.daily.newSeen++;patchProgress(kind,id,p)}}
  function setStatus(kind,id,status){
    const p=progress(kind,id),now=Date.now();p.status=status;p.lastSeen=now;
    if(status==='learned'){p.reps=Math.max(p.reps,3);p.interval=Math.max(p.interval,7);p.due=now+p.interval*DAY}
    else if(status==='unsure'){p.due=now+TEN_MIN}
    else {p.reps=0;p.interval=0;p.due=0}
    markNewSeen(kind,id);patchProgress(kind,id,p);
  }
  function review(kind,id,gradeOrCorrect,responseMs=0,source='quiz'){
    const now=Date.now(),p=progress(kind,id);let grade=typeof gradeOrCorrect==='boolean'?(gradeOrCorrect?4:0):Number(gradeOrCorrect);if(![0,2,4].includes(grade))grade=0;
    p.lastSeen=now;p.lastMs=responseMs;if(state.daily.date!==today())state.daily={date:today(),newSeen:0,asked:0,correct:0,wrong:0,hard:0,ms:0};if(!p.newSeen)markNewSeen(kind,id);
    const correct=grade===4,hard=grade===2;p.correct=Number(p.correct||0);p.wrong=Number(p.wrong||0);p.hard=Number(p.hard||0);
    if(correct){p.correct++;p.ease=Math.min(3,Number(p.ease||2.5)+.08);p.reps++;p.interval=p.reps===1?1:p.reps===2?3:p.reps===3?7:Math.max(7,Math.round((p.interval||7)*p.ease));p.status=p.reps>=3?'learned':'unsure';p.due=now+p.interval*DAY}
    else if(hard){p.hard++;p.ease=Math.max(1.5,Number(p.ease||2.5)-.05);p.status='unsure';p.due=now+30*60000}
    else{p.wrong++;p.ease=Math.max(1.3,Number(p.ease||2.5)-.2);p.reps=0;p.interval=0;p.status='unsure';p.due=now+TEN_MIN}
    patchProgress(kind,id,p);state.daily.asked++;state.daily.ms+=responseMs;if(correct)state.daily.correct++;else if(hard)state.daily.hard++;else state.daily.wrong++;
    state.reviewLog.push({t:now,kind,id,grade,correct,hard,responseMs,source});state.reviewLog=state.reviewLog.slice(-5000);state.lastSession={t:now,kind,id,grade,source};return p;
  }
  function dueItems(kind){const now=Date.now();return Object.values(state.progress).filter(p=>p.id.startsWith(kind+':')&&p.status!=='new'&&p.due&&p.due<=now)}
  function counts(kind,ids){let n=0,u=0,l=0,d=0;for(const id of ids){const p=progress(kind,id);if(p.status==='new')n++;else if(p.status==='unsure')u++;else if(p.status==='learned')l++;if(p.due&&p.due<=Date.now()&&p.status!=='new')d++}return{new:n,unsure:u,learned:l,due:d,total:ids.length}}
  function hardest(limit=12){return Object.values(state.progress).filter(p=>(p.wrong||0)>0||(p.hard||0)>0).sort((a,b)=>((Number(b.wrong||0)*2+Number(b.hard||0))-(Number(b.correct||0)))-((Number(a.wrong||0)*2+Number(a.hard||0))-(Number(a.correct||0)))||b.wrong-a.wrong).slice(0,limit)}
  function sessionStats(){const recent=state.reviewLog.slice(-200);const total=recent.length,ok=recent.filter(x=>x.grade===4||x.correct===true).length,hard=recent.filter(x=>x.grade===2||x.hard).length;return{total,ok,hard,rate:total?Math.round(ok/total*100):0,avgMs:total?Math.round(recent.reduce((n,x)=>n+(x.responseMs||0),0)/total):0}}
  function studyStreak(){
    const days=new Set((state.reviewLog||[]).filter(x=>x&&x.t).map(x=>new Date(x.t).toISOString().slice(0,10)));
    let d=new Date();let streak=0;
    while(true){const key=d.toISOString().slice(0,10);if(!days.has(key))break;streak++;d.setUTCDate(d.getUTCDate()-1)}
    return streak;
  }
  async function exportJson(){
    const payload={app:'Kanji-Sammler',version:9,exportedAt:new Date().toISOString(),schema:9,state:clone(state)};
    const a=document.createElement('a'),blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});a.href=URL.createObjectURL(blob);a.download='kanji-sammler-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500)
  }
  async function importJson(file){const p=JSON.parse(await file.text());const incoming=p.state||p;if(!incoming||!Array.isArray(incoming.folders)||!Array.isArray(incoming.cards))throw new Error('Ungültiges Backup');state={...base(),...incoming,schema:9};ensure();await persist()}
  async function resetProgress(){state.progress={};state.daily={date:today(),newSeen:0,asked:0,correct:0,wrong:0,hard:0,ms:0};state.reviewLog=[];state.lastSession=null;await persist()}
  window.KS_STORE={load,get,persist,progress,patchProgress,setStatus,review,dueItems,counts,hardest,sessionStats,studyStreak,exportJson,importJson,resetProgress,markNewSeen};
})();
