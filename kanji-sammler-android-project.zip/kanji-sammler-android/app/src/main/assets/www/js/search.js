/* Ranked local search. Search results connect German seed words back to Kanji. */
(function(){
  'use strict';
  const norm=v=>String(v??'').toLocaleLowerCase('de-DE').normalize('NFKC').trim();
  const kanaRows=s=>KS_DATA.kanaRows(s);
  const joyo=new Set(KS_DATA.joyoChars());
  const hiraToRoma=[['し','shi'],['ち','chi'],['つ','tsu'],['ふ','fu'],['じ','ji'],['ぢ','ji'],['づ','zu'],['しゃ','sha'],['しゅ','shu'],['しょ','sho'],['ちゃ','cha'],['ちゅ','chu'],['ちょ','cho'],['じゃ','ja'],['じゅ','ju'],['じょ','jo'],['ふぁ','fa'],['ふぃ','fi'],['ふぇ','fe'],['ふぉ','fo']];
  const romaMap={あ:'a',い:'i',う:'u',え:'e',お:'o',か:'ka',き:'ki',く:'ku',け:'ke',こ:'ko',さ:'sa',す:'su',せ:'se',そ:'so',た:'ta',ち:'chi',つ:'tsu',て:'te',と:'to',な:'na',に:'ni',ぬ:'nu',ね:'ne',の:'no',は:'ha',ひ:'hi',ふ:'fu',へ:'he',ほ:'ho',ま:'ma',み:'mi',む:'mu',め:'me',も:'mo',や:'ya',ゆ:'yu',よ:'yo',ら:'ra',り:'ri',る:'ru',れ:'re',ろ:'ro',わ:'wa',を:'wo',ん:'n',が:'ga',ぎ:'gi',ぐ:'gu',げ:'ge',ご:'go',ざ:'za',じ:'ji',ず:'zu',ぜ:'ze',ぞ:'zo',だ:'da',ぢ:'ji',づ:'zu',で:'de',ど:'do',ば:'ba',び:'bi',ぶ:'bu',べ:'be',ぼ:'bo',ぱ:'pa',ぴ:'pi',ぷ:'pu',ぺ:'pe',ぽ:'po',ゔ:'vu',っ:''};
  const romanToKana=v=>norm(v);
  function romaji(s){let x=String(s||'');for(const[a,b]of [...hiraToRoma].sort((a,b)=>b[0].length-a[0].length))x=x.replaceAll(a,b);for(const[k,v]of Object.entries(romaMap))x=x.replaceAll(k,v);return norm(x)}
  function fieldsForKanji(d){return [...(d?.on_readings||d?.on||[]),...(d?.kun_readings||d?.kun||[]),...(d?.name_readings||d?.nanori||[]),...(d?.meanings||[]),d?.meaning||'',d?.heisig_en||'',d?.radical_name||'',...(d?.radicals||[])].filter(Boolean)}
  function score(fields,q,exact=false){const n=norm(q);if(exact)return 1000;let best=0;for(const f0 of fields){const f=norm(f0),fr=romaji(f0);if(!f)continue;if(f===n||fr===n)best=Math.max(best,300);else if(f.startsWith(n)||fr.startsWith(n))best=Math.max(best,200);else if(f.includes(n)||fr.includes(n))best=Math.max(best,110)}return best}
  function seedMatches(query){
    const rows=[];
    for(const w of KS_DATA.getWordSeed()){
      const s=score([w.de,w.word,w.reading,w.meaning,romaji(w.reading)],query);
      if(s)rows.push({...w,score:s});
    }
    return rows.sort((a,b)=>b.score-a.score);
  }
  function search(q,filter='all'){
    const query=norm(q);if(!query)return[];const out=[],seeds=seedMatches(query), chars=KS_DATA.allKanjiChars();
    if(filter==='all'||filter==='word')for(const w of seeds)out.push({type:'word',key:'seed:'+w.de,score:w.score+15,word:w.word,reading:w.reading,meaning:w.meaning,source:w.source});
    if(filter==='all'||filter==='kanji'){
      const linked=new Map();
      for(const w of seeds)for(const ch of [...String(w.word||'')])if(chars.includes(ch))linked.set(ch,Math.max(linked.get(ch)||0,w.score+35));
      for(const ch of chars){const d=KS_DATA.getKanji(ch),f=[ch,...fieldsForKanji(d)],s=score(f,query,ch===q),ls=linked.get(ch)||0,b=(joyo.has(ch)?9:0)+(d.frequency?Math.max(0,20-Math.min(20,Number(d.frequency)/150)):0),total=Math.max(s+b,ls);
        if(total)out.push({type:'kanji',key:ch,score:total,char:ch,details:d,isJoyo:joyo.has(ch),linkedFromSeed:!!ls});
      }
    }
    if(filter==='all'||filter==='kana')for(const script of ['hiragana','katakana'])for(const x of kanaRows(script)){const s=score([x.char,x.reading,x.category,romaji(x.reading)],query,x.char===q);if(s)out.push({type:'kana',key:x.id,score:s,item:x})}
    for(const c of KS_STORE.get().cards||[]){const s=score([c.front,c.reading,c.meaning,c.notes,romaji(c.reading)],query);if(s)out.push({type:'card',key:c.id,score:s+35,card:c})}
    return out.sort((a,b)=>b.score-a.score).slice(0,300);
  }
  window.KS_SEARCH={search,norm,romaji,fieldsForKanji,seedMatches,romanToKana};
})();
