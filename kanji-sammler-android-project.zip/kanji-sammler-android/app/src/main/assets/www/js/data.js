/* Kanji-Sammler v0.9 data/catalog layer. Offline-first, source-separated, cache-aware. */
(function(){
  'use strict';
  const API='https://kanjiapi.dev/v1';
  let ready=false, remote=new Map(), allChars=[];
  const joyo=()=>String(window.KS_KANJI_CATALOG?.joyo||'');
  const details=()=>window.KS_KANJI_CATALOG?.details||{};
  const words=()=>window.KS_WORD_SEED?.german||{};
  const kana=()=>window.KS_KANA_DATA?.kana||{};
  const sources=()=>window.KS_SOURCES?.sources||{};
  const uniq=a=>[...new Set((a||[]).filter(Boolean))];
  function joyoChars(){return [...new Set([...joyo()])];}
  function japaneseOnly(v){return /[\u3040-\u30ff\u3400-\u9fff]/.test(String(v||''));}
  function derivedSeedDetails(){
    const out={};
    for(const [,v] of Object.entries(words())){
      if(!Array.isArray(v)||!v.length)continue;
      const jp=String(v[0]||''), rd=String(v[1]||''), meaning=String(v[2]||'');
      const chars=[...jp].filter(ch=>joyo().includes(ch));
      if(chars.length===1 && japaneseOnly(jp)){
        const ch=chars[0], prev=out[ch]||{kanji:ch,meanings:[],on_readings:[],kun_readings:[],name_readings:[],stroke_count:null,grade:null,jlpt:null,frequency:null,radicals:[],source:'deutscher Offline-Seed'};
        if(meaning&&!prev.meanings.includes(meaning))prev.meanings.push(meaning);
        if(rd&&japaneseOnly(rd)){
          const reading=rd.split(/[ /·,]+/).filter(Boolean)[0]||rd;
          if(/[ぁ-ゖ]/.test(reading)){if(!prev.kun_readings.includes(reading))prev.kun_readings.push(reading)}
          else if(/[ァ-ヺ]/.test(reading)){if(!prev.on_readings.includes(reading))prev.on_readings.push(reading)}
        }
        out[ch]=prev;
      }
    }
    return out;
  }
  let seedDerived=null;
  function getKanji(ch){
    if(!seedDerived)seedDerived=derivedSeedDetails();
    const r=remote.get(ch), s=details()[ch], d=seedDerived[ch];
    if(r)return {...r,kanji:ch};
    if(s)return {...s,kanji:ch};
    if(d)return {...d,kanji:ch};
    return {kanji:ch,meanings:[],on_readings:[],kun_readings:[],name_readings:[],stroke_count:null,grade:null,jlpt:null,frequency:null,radicals:[],source:'Jōyō-Katalog ohne Detaildatensatz'};
  }
  function kanaRows(script){
    const groups=[['basic','basic'],['dakuten / handakuten','voiced'],['yōon','yoon'],['foreign','foreign'],['small','small']];
    const out=[],seen=new Set();
    for(const [category,key] of groups)for(const pair of (kana()[key]||[])){
      const [h,k,r]=pair||[],ch=script==='hiragana'?h:k;
      if(!ch||seen.has(ch))continue;
      seen.add(ch);out.push({id:script+':'+ch,kind:'kana',script,char:ch,paired:script==='hiragana'?k:h,reading:r,category});
    }
    return out;
  }
  function allKanjiChars(){return allChars.length?[...allChars]:joyoChars()}
  function getWordSeed(){return Object.entries(words()).map(([de,[word,reading,meaning]])=>({de,word,reading,meaning,source:'Offline-Wort-Seed'}))}
  async function load(){
    try{
      const dict=await KS_DB.all('dictionary');
      for(const r of dict||[])if(r.kind==='kanji'&&r.kanji)remote.set(r.kanji,r);
      const m=await KS_DB.get('meta','catalog');allChars=Array.isArray(m?.allChars)?uniq(m.allChars):[];
    }catch(e){/* local fallback is handled by store */}
    seedDerived=null;ready=true;
  }
  async function getWords(ch){
    const id='words:'+ch,cached=await KS_DB.get('dictionary',id);
    if(cached?.words)return cached.words;
    if(!navigator.onLine)return[];
    try{const r=await fetch(API+'/words/'+encodeURIComponent(ch),{cache:'no-store'});if(!r.ok)return[];const w=await r.json();await KS_DB.put('dictionary',{id,kind:'words',kanji:ch,words:w,source:'kanjiapi.dev'});return w}catch(e){return[]}
  }
  async function getStroke(ch){
    const id='stroke:'+ch,cached=await KS_DB.get('stroke',id);if(cached?.svg)return cached.svg;
    if(!navigator.onLine)return null;
    const hex=ch.codePointAt(0).toString(16).padStart(5,'0');
    try{const r=await fetch('https://raw.githubusercontent.com/KanjiVG/kanjivg/master/kanji/'+hex+'.svg',{cache:'force-cache'});if(!r.ok)return null;const svg=await r.text();await KS_DB.put('stroke',{id,kanji:ch,svg,source:'KanjiVG'});return svg}catch(e){return null}
  }
  async function jsonFetch(url,timeout=60000){const c=new AbortController(),t=setTimeout(()=>c.abort(),timeout);try{const r=await fetch(url,{cache:'no-store',signal:c.signal});if(!r.ok)throw new Error(String(r.status));return await r.json()}finally{clearTimeout(t)}}
  async function sync(){
    if(!navigator.onLine||location.protocol==='file:')return false;
    window.dispatchEvent(new CustomEvent('ks-sync',{detail:{running:true,ok:false}}));let ok=false;
    try{
      const chars=await jsonFetch(API+'/kanji/all',45000);if(Array.isArray(chars)&&chars.length>5000){allChars=uniq(chars);await KS_DB.put('meta',{id:'catalog',allChars});ok=true}
      try{
        const enriched=await jsonFetch(API+'/kanji/all-enriched',90000);if(Array.isArray(enriched)&&enriched.length>5000){for(let i=0;i<enriched.length;i+=200)await KS_DB.bulkPut('dictionary',enriched.slice(i,i+200).map(x=>({id:'kanji:'+x.kanji,kind:'kanji',kanji:x.kanji,...x,source:'kanjiapi.dev'})));for(const x of enriched)remote.set(x.kanji,{...x,kind:'kanji'});ok=true}
      }catch(e){
        try{const enriched=await jsonFetch(API+'/kanji/joyo-enriched',60000);if(Array.isArray(enriched)&&enriched.length>1500){for(let i=0;i<enriched.length;i+=200)await KS_DB.bulkPut('dictionary',enriched.slice(i,i+200).map(x=>({id:'kanji:'+x.kanji,kind:'kanji',kanji:x.kanji,...x,source:'kanjiapi.dev'})));for(const x of enriched)remote.set(x.kanji,{...x,kind:'kanji'});ok=true}}catch(_){}
      }
      await KS_DB.put('meta',{id:'lastSync',value:Date.now()});
    }catch(e){console.warn('Kanji-Synchronisierung fehlgeschlagen',e)}
    finally{window.dispatchEvent(new CustomEvent('ks-sync',{detail:{running:false,ok}}))}
    return ok;
  }
  async function maybeSync(){try{const m=await KS_DB.get('meta','lastSync'),stale=!m?.value||(Date.now()-m.value>30*86400000);if(location.protocol!=='file:'&&navigator.onLine&&stale)setTimeout(()=>sync(),1000)}catch(e){}}
  const confusion=[['未','末'],['土','士'],['人','入'],['大','太','犬'],['日','目'],['口','囗'],['木','本'],['千','干'],['王','玉'],['白','百'],['天','夫'],['牛','午'],['右','石'],['夕','外'],['刀','力'],['己','已','巳'],['目','自']];
  function norm(v){return String(v||'').normalize('NFKC').toLocaleLowerCase('de-DE').trim()}
  function fieldsFor(d){return [...(d.on_readings||d.on||[]),...(d.kun_readings||d.kun||[]),...(d.name_readings||d.nanori||[]),...(d.meanings||[]),d.meaning||'',d.radical_name||'',...(d.radicals||[])].filter(Boolean)}
  function similar(ch){
    const target=fieldsFor(getKanji(ch)).map(norm).filter(Boolean);if(!target.length)return[];
    return allKanjiChars().filter(x=>x!==ch).map(x=>{const fs=fieldsFor(getKanji(x)).map(norm);let s=0;for(const f of fs)if(target.includes(f))s++;return[x,s]}).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]).slice(0,8).map(x=>x[0]);
  }
  function groupsFor(ch){return confusion.filter(g=>g.includes(ch))}
  function stats(){return{joyo:joyoChars().length,all:allKanjiChars().length,detailed:[...new Set([...remote.keys(),...Object.keys(details()),...Object.keys(seedDerived||{})])].length,kanaH:kanaRows('hiragana').length,kanaK:kanaRows('katakana').length,wordSeed:Object.keys(words()).length,online:navigator.onLine}}
  window.KS_DATA={load,sync,maybeSync,getKanji,getWords,getStroke,kanaRows,joyoChars,allKanjiChars,getWordSeed,similar,groupsFor,stats,get remoteSize(){return remote.size},get ready(){return ready},get sources(){return sources()}};
})();
